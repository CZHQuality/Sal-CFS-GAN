################################ Testing ################################
# labels only
python test.py --name label2city_512p